<?php
include 'koneksi.php';

$nama = $_POST['nama'];
$uid = $_POST['uid'];
$server = $_POST['server'];
$ar_sekarang = $_POST['ar_sekarang'];
$ar_tujuan = $_POST['ar_tujuan'];
$world_level = $_POST['world_level'];
$spiral_abyss = $_POST['spiral_abyss'];
$catatan = $_POST['catatan'];

$sql = "INSERT INTO order_genshin (nama, uid, server, ar_sekarang, ar_tujuan, world_level, spiral_abyss, catatan)
        VALUES ('$nama', '$uid', '$server', '$ar_sekarang', '$ar_tujuan', '$world_level', '$spiral_abyss', '$catatan')";

if ($koneksi->query($sql) === TRUE) {
    echo "Order Genshin berhasil dikirim!";
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

$koneksi->close();
