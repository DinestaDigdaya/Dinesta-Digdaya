<?php
include 'koneksi.php';

$nama = $_POST['nama'];
$game = $_POST['game'];
$rank_sekarang = $_POST['rank_sekarang'];
$rank_tujuan = $_POST['rank_tujuan'];
$catatan = $_POST['catatan'];

$sql = "INSERT INTO order_umum (nama, game, rank_sekarang, rank_tujuan, catatan)
        VALUES ('$nama', '$game', '$rank_sekarang', '$rank_tujuan', '$catatan')";

if ($koneksi->query($sql) === TRUE) {
    echo "Order berhasil dikirim!";
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

$koneksi->close();
